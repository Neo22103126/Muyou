<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@300;400;500&display=swap" rel="stylesheet">
    <link href="../css/boot.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
    <link href="../css/login.css" rel="stylesheet">
    <link href="../css/formulario.css" rel="stylesheet">
    <link href="../css/fonticon.css" rel="stylesheet">
    <script type="text/javascript" src="../js/modal.js"></script>
    <link href="../css/modal.css" rel="stylesheet">
    <title>Cadastro</title>
</head>

<body>
    <!--DOBRA CABEÇALHO-->

    <header class="main_header">
        <div class="main_header_content">
            <a href="index.html" class="logo">
                <img src="../img/logo.png" alt="Bem vindo ao projeto prático Html5 e Css3 Essentials"
                    title="Bem vindo ao projeto prático Html5 e Css3 Essentials"></a>

                    <nav class="main_header_content_menu">
                        <ul>
                            <li><a href="index.html">Home</a></li>
                                                       
                        </ul>
                    </nav>
        </div>
    </header>

    <style>
        .main_cta {
            width: 100%;
            background-image: url('../img/bg_main_home.png');
            background-color: #2d3142;
            background-repeat: no-repeat;
            background-position: center center;
            background-size: cover;
        }
    </style>

    <main>
        <div class="main_opc">

            <section class="main_course" id="escola">
                <header class="main_course_header">

                </header>
                <div class="main_course_content">
                    <article>
                        <h2 align="center">Cadastrar dados</h2>
                        <header>
                            
                            <p align="center">
                                <a href="singup.php"><img src="../img/cadastro.png" width="200"></a></p>
                               
                        </header>
                    </article>
                    <article>
                        <h2 align="center">Alterar dados</h2>
                        <header>
                            
                            <p align="center"><a href="listarUsuarios.php"><img src="../img/listar.png" width="350"></a></p>
                            
                        </header>
                    </article>

                </div>
                </article>
            </section>
            </div>

    </main>
    <!--FIM DOBRA PALCO PRINCIPAL-->

</body>


</html>