<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../css/login.css">
    <title>Muyou Cadastro</title>
    <style>
    .btn-back {
        display: inline-block;
        padding: 3px 10px;
        background-color: #111727;
        color: #fff;
        text-decoration: none;
        border-radius: 5px;
        transition: background-color 0.3s ease;
        border: none;
        font-weight: bold;
        margin-top: 20px;
    }

    .btn-back:hover {
        background-color: #111727;
    }
    </style>
</head>

<body>
    <header>
        <div class="left_bx1">
            <div class="content">
                <form action="../Control/CadastrarUsuarioControl.php" method="POST">
                    <h3>Cadastro</h3>
                    <div class="card">
                        <label for="nomeUsuario">Nome</label>
                        <input type="text" id="nomeUsuario" name="nomeUsuario" placeholder="Nome de Usuário..." required>
                    </div>
                    <div class="card">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" placeholder="Digite seu Email..." required>
                    </div>
                    <div class="card">
                        <label for="senha">Senha</label>
                        <input type="password" id="senha" name="senha" placeholder="Digite sua Senha..." required>
                    </div>
                    <div class="card">
                        <label for="telefone">Telefone</label>
                        <input type="text" id="telefone" name="telefone" placeholder="Digite seu Telefone..." required>
                    </div>
                    <div class="card">
                        <label>Data de Nascimento</label>
                        <input type="date" name="dtNascimento" required>
                    </div>
                    <div class="card">
                        <label for="genero">Gênero Musical:</label>
                        <input type="text" id="genero" name="genero" required>
                    </div>
                    
                    <div class="card">

                    <label for="biografia">Biografia:</label><br>
                    <textarea id="biografia" name="biografia" rows="4" cols="50"></textarea>

                    </div>

                    <input type="submit" value="Salvar" class="submit">
                    <div class="check">
                        <input type="checkbox" name="" id=""><span>Lembrar de mim.</span>
                    </div>
                    <p>Já tem uma conta? <a href="login.php">Login</a></p>
                </form>
                <a href="../index.php" class="btn-back">Voltar</a>
            </div>
        </div>
        
    </header>
</body>

</html>
