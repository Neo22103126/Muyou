<?php
    session_start();
    if(!isset($_SESSION["idUsuario"])){
      header ( "location:../index.php?msg=Usuário e/ou senha inválidos" );	
	  exit; 
    }
    
    //Pesquisar no banco o usuario a ser alterado

    $usuarioLogin =$_SESSION["nomeUsuario"];
    $idUsuarioLogin = $_SESSION["idUsuario"];
    $usuarioLoginPerfil =$_SESSION["perfil_idPerfil"];
    require_once "../Model/UsuarioDTO.php";
    require_once "../Model/UsuarioDAO.php";

    $usuarioDAO = new UsuarioDAO();
    
    $usuarios = $usuarioDAO->listarUsuarios();
    
    if($usuarios == Null){
        header ( "location:../index.php?msg=Usuários não encontrados!" );	
        exit;    
    }

 ?>  
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@300;400;500&display=swap" rel="stylesheet">
    <link href="../css/boot.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
    <link href="../css/fonticon.css" rel="stylesheet">
    <link href="../css/lista.css" rel="stylesheet">


    <title>LISTAGEM DE USUÁRIOS</title>
</head>

<body>
    <!--DOBRA CABEÇALHO-->

    <header class="main_header">
        <div class="main_header_content">
        
            <div class="listagem_info">
                <samp class="icon-books">Listagem de Usuários</samp>
           </div>
       </div>

           
        </div>
    </header>
    <!--FIM DOBRA CABEÇALHO-->

    <!--DOBRA PALCO PRINCIPAL-->

    <!--1ª DOBRA-->
    <main>

        <div class="main_stage">
            <div class="main_stage_content">
               
                <article>
                    <header>
                       
                        <table border="0" width="1300px" class="table">
                            
                            <tr>
                                <th>Nome</th>
                                <th>Telefone</th>
                                <th>Email</th>
                                <th>Função</th>
                                <th>Situacao</th>
                                

                            </tr>
                            <?php
                                foreach($usuarios as $u) {
                                   echo '<tr>
                                   <td>'.$u["nomeUsuario"].'</td>
                                   <td>'.$u["telefone"].'</td>
                                   <td>'.$u["email"].'</td>
                                   <td>'.$u["perfil_idPerfil"].'</td>
                                   <td>'.$u["situacaoUsuario"].'</td>                           
                                   <td><button class="btn"><a href="AlterarUsuario.php?idUsuario='.$u["idUsuario"].'">Editar</a?></button>&nbsp;
                                      <button class="btn"><a href="../Control/ApagarUsuarioControl.php?idUsuario='.$u["idUsuario"].'">Apagar</a?></button>&nbsp;
                                   </td> </tr>';     
                                }

                            ?>
                            
                               
                            
                        </table>
                        
                    </header>
               </article>
               
            </div>
        </div>
        <!--FIM DOBRA PALCO PRINCIPAL-->




        
        <!--INCIIO DOBRA RODAPE-->
        <section class="main_optin_footer">
            <div class="main_optin_footer_content">
                <header>
                    <h1></h1>
                </header>
                <article>
                    <header>
                        <h2><a href="../index.php" class="btn">Voltar</a></h2>
                    </header>
                </article>
            </div>
        </section>
        <!--FIM DOBRA RODAPE-->
    </main>
</body>

</html>