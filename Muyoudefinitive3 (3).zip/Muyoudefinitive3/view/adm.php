<?php 
echo '<nav class="main_header_content_menu">
                <ul>
                    <li><a href="">Home</a></li>
                    <li><a href="">Blog</a></li>
                    <li><a href="#escola">Escola</a></li>
                    <li><a href="#contato">Contato</a></li>
                    <li><a href="" class="modal-link">Login</a></li>
                    <li><a href="View/opcao.php">Cadastrar</a></li>
                </ul>
             </nav>';

?>