<?php
    session_start();
    if(!isset($_SESSION["idUsuario"])){
      header ( "location:../index.php?msg=Usuário e/ou senha inválidos" );	
	  exit; 
    }
    
    if(!isset($_GET["idUsuario"])){
      header ( "location:../index.php?msg=Usuário não selecionado!" );	
      exit;   
    }
    //Pesquisar no banco o usuario a ser alterado

    $usuarioLogin =$_SESSION["nomeUsuario"];
    $idUsuarioLogin = $_SESSION["idUsuario"];
    $usuarioLoginPerfil =$_SESSION["perfil_idPerfil"];

    require_once "../Model/UsuarioDTO.php";
    require_once "../Model/UsuarioDAO.php";

    $usuarioDAO = new UsuarioDAO();
    $idUsuario = $_GET["idUsuario"];
    
    $usuario = $usuarioDAO->buscarUsuarioPorId($idUsuario);
    
    if($usuario == Null){
        header ( "location:../index.php?msg=Usuário não encontrado!" );	
        exit;    
    }

 ?>   
<!DOCTYPE html>
<html lang="pt-br">

<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@300;400;500&display=swap" rel="stylesheet">
    <link href="../css/boot.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
    <link href="../css/login.css" rel="stylesheet">
    <link href="../css/formulario.css" rel="stylesheet">
    <link href="../css/fonticon.css" rel="stylesheet">
    <script type="text/javascript" src="../js/modal.js"></script>
    <link href="../css/modal.css" rel="stylesheet">
    <title>Alteração de Usuário</title>
</head>

<body>
    <!--DOBRA CABEÇALHO-->

    <header class="main_header">
        <div class="main_header_content">
            <a href="../index.php" class="logo">
                <img src="../img/logo.png" alt="Bem vindo ao projeto prático Html5 e Css3 Essentials"
                    title="Bem vindo ao projeto prático Html5 e Css3 Essentials"></a>
                    <div class="listagem_info">
                        <samp class="icon-blog">Cadastro de Dados </samp>
                        
                   </div>
                   
                   
                   
        </div>
    </header>

    <style>
        
.main_cta{
    width:100%;
    background-image: url('../img/bg_main_home.png');
    background-color: #2d3142;
    background-repeat: no-repeat;
    background-position: center center;
    background-size: cover;
}
    </style>

    <main>

        <div class="box">

            <form action="../Control/alterarUsuarioControl.php" method="POST">
                <fieldset ">
                    <legend><b>Alteração de Usuário</b></legend>
                    <br>
                    <div class="inputBox">
                        <input type="text" name="nomeUsuario" id="nomeUsuario" class="inputUser" value="<?php echo $usuario["nomeUsuario"]; ?>" required>
                        <label for="nomeUsuario" class="labelInput">Nome completo</label>
                    </div>
                    <br>
                    <div class="inputBox">
                        <input type="text" name="email" id="email" class="inputUser" value="<?php echo $usuario["email"]; ?>" required>
                        <label for="email" class="labelInput">Email</label>
                    </div>
                    <br>
                    <div class="inputBox">
                        <input type="tel" name="telefone" id="telefone" class="inputUser" value="<?php echo $usuario["telefone"]; ?>" required>
                        <label for="telefone" class="labelInput">Telefone</label>
                    </div>
                    <br>
                    <div class="inputBox">
                        <input type="tel" name="cpf" id="cpf" class="inputUser" required>
                        <label for="cpf" class="labelInput">CPF:</label>
                    </div>
                    <br>
                    <div class="inputBox">
                    <p>Sexo:</p>
                    <input type="radio" id="feminino" name="sexo" value="Feminino" <?php if($usuario["sexo"] == 'Feminino') echo 'Selected'; ?> required>
                    <label for="sexo">Feminino</label>
                    <BR>
                    
                    <input type="radio" id="masculino" name="sexo" value="Masculino" <?php if($usuario["sexo"] == 'Masculino') echo 'Selected'; ?> required>
                    <label for="sexo">Masculino</label>
                    <br>
                    <input type="radio" id="outro" name="sexo" value="Outro" required>
                    <label for="sexo">Outro</label>
                    </div>
                    <br>
                    <div class="inputBox">
                        <input type="date" name="dtNascimento" id="dtNascimento" class="inputUser" required>
                        <label for="dtNascimento" class="labelInput">Data de Nascimento:</label>
                    </div>
                    <br>
                    <div class="inputBox">
                        <input type="text" name="endereco" id="endereco" class="inputUser" required>
                        <label for="endereco" class="labelInput">Endereço</label>
                    </div>
                    <br>
                    <div class="inputBox">
                        <input type="text" name="numero" id="numero" class="inputUser" required>
                        <label for="numero" class="labelInput">Número</label>
                    </div>
                    <br>
                    <div class="inputBox">
                        <input type="text" name="complemento" id="complemento" class="inputUser" required>
                        <label for="complemento" class="labelInput">Complemento</label>
                    </div>
                    <br>
                    <div class="inputBox">
                        <input type="text" name="bairro" id="bairro" class="inputUser" required>
                        <label for="bairro" class="labelInput">Bairro</label>
                    </div>
                    <br>

                    <div class="inputBox">
                        <input type="text" name="cidade" id="cidade" class="inputUser" required>
                        <label for="cidade" class="labelInput">Cidade</label>
                    </div>
                    <br>
                    <div class="inputBox">                        
                    <select id="estado" class="inputUser" name="uf">
                        <option value="" selected>Selecione um Estado</option>
                        <option value="AC">Acre</option>
                        <option value="AL">Alagoas</option>
                        <option value="AP">Amapá</option>
                        <option value="AM">Amazonas</option>
                        <option value="BA">Bahia</option>
                        <option value="CE">Ceará</option>
                        <option value="DF">Distrito Federal</option>
                        <option value="ES">Espírito Santo</option>
                        <option value="GO">Goiás</option>
                        <option value="MA">Maranhão</option>
                        <option value="MT">Mato Grosso</option>
                        <option value="MS">Mato Grosso do Sul</option>
                        <option value="MG">Minas Gerais</option>
                        <option value="PA">Pará</option>
                        <option value="PB">Paraíba</option>
                        <option value="PR">Paraná</option>
                        <option value="PE">Pernambuco</option>
                        <option value="PI">Piauí</option>
                        <option value="RJ">Rio de Janeiro</option>
                        <option value="RN">Rio Grande do Norte</option>
                        <option value="RS">Rio Grande do Sul</option>
                        <option value="RO">Rondônia</option>
                        <option value="RR">Roraima</option>
                        <option value="SC">Santa Catarina</option>
                        <option value="SP">São Paulo</option>
                        <option value="SE">Sergipe</option>
                        <option value="TO">Tocantins</option>
                        <option value="EX">Estrangeiro</option>
                    </select>
                        <label for="uf" class="labelInput">UF:</label>
                    </div>
                    <br><br>
                    <div class="inputBox">
                        <input type="text" name="cep" id="cep" class="inputUser" required>
                        <label for="cep" class="labelInput">CEP:</label>
                    </div>
                    <br><br>
                    <?php
                        //testa se é o administrador 
                        if($usuarioLoginPerfil=="1"){
                            //caso seja o usuário administrador, habilita o Perfil e a Situação do Usuário
                            echo '<div class="inputBox">
                            <select id="perfil_idPerfil" class="inputUser" name="perfil_idPerfil">
                               <option value="1" selected>Administrador</option>
                               <option value="2">Cliente</option>
                               <option value="3">Funcionário</option>
                            </select>
                            <label for="perfil_idPerfil" class="labelInput">Perfil do Usuário:</label>
                            </div><br><br>
                            <div class="inputBox">
                            <select id="situacaoUsuario" class="inputUser" name="situacaoUsuario">
                               <option value="Ativo" selected>Ativo</option>
                               <option value="Inativo">Inativo</option>
                               <option value="Bloqueado">Bloqueado</option>
                            </select>
                            <label for="situacaoUsuario" class="labelInput">Situação do Usuário:</label>
                            </div><br><br>';
                            
                        } else {
                           //caso NÃO seja o administrador, esconde o Perfil e a Situação do Usuário 
                           echo '<input type="hidden" name="perfil_idPerfil" value="2">
                                <input type="hidden" name="situacaoUsuario" value="Ativo">';
                        }
                    ?>
                    <div class="inputBox">
                        <input type="password" name="senha" id="senha" class="inputUser" required>
                        <label for="senha" class="labelInput">Senha:</label>                         
                    </div>
                    <br><br>

                </fieldset>
                <div class="btn_alinhamento">
                    <input type="submit" name="submit" id="submit" value="Salvar" class="submit">
                    <input type="reset" name="reset" id="reset" value="Limpar" class="submit">
                </div>
                
            </form>
        </div>
        <!--FIM 1ª DOBRA-->

        

    </main>
    <!--FIM DOBRA PALCO PRINCIPAL-->

</body>

</html>