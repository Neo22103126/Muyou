<!DOCTYPE html>
<html>

<head>
    <title>Muyou</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 20px;
        background-color: #000000;
        color: #ffffff;
    }

    .container {
        display: flex;
        justify-content: space-between;
    }

    .sidebar {
        width: 200px;
        background-color: #121213;
        padding: 20px;
        position: fixed;
        height: 100%;
        overflow-y: auto;
    }

    .sidebar h2 {
        color: #ffffff;
        margin-top: 0;
    }

    .sidebar button {
        display: block;
        width: 100%;
        padding: 10px;
        margin-top: 20px;
        border: none;
        border-radius: 4px;
        background-color: #ff0000;
        color: #ffffff;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .sidebar button:hover {
        background-color: #505050;
    }

    .content {
        flex: 1;
        margin-left: 240px;
    }

    .card-container {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 20px;
    }

    .card {
        position: relative;
        background-color: #333;
        border-radius: 4px;
        padding: 20px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        transition: all 0.3s ease;
        cursor: pointer;
        overflow: hidden;
    }

    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
    }

    .card img {
        width: 100%;
        height: auto;
        border-radius: 4px;
        object-fit: cover;
    }

    .card-content {
        padding: 20px;
        background-color: rgba(0, 0, 0, 0.7);
        transition: all 0.3s ease;
    }

    .card-content button {
        display: block;
        width: 100%;
        padding: 10px;
        margin-top: 20px;
        border: none;
        border-radius: 4px;
        background-color: #ff0000;
        color: #ffffff;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .card:hover .card-content {
        height: 120px;
    }

    .card h3 {
        margin: 0;
        font-size: 20px;
        color: #f5f5f5;
        margin-bottom: 10px;
    }

    .card p {
        margin: 0;
        font-size: 16px;
        color: #f5f5f5;
    }

    .card span {
        font-size: 14px;
        color: #999;
    }

    audio {
        width: 100%;
        margin-top: 20px;
    }
    </style>
</head>

<body>
    <div class="container">
        <div class="sidebar">
            <h2>Menu</h2>
            <button onclick="goBack()">Voltar</button>
        </div>
        <div class="content">
            <div class="card-container">
                <div class="card">
                    <img src="https://i1.sndcdn.com/artworks-FV0nLBEngwtabt9o-Au37zQ-t500x500.jpg" alt="Capa do Álbum">
                    <div class="card-content">
                        <h3>Rasputin</h3>
                        <p>BoneyM</p>
                        <span>Album</span>
                        <span>1978</span>
                        <audio id="audio3" src="1.mp3" type="audio/mpeg"></audio>
                        <button onclick="toggleAudio('audio3')">Play/Pause</button>
                    </div>
                </div>

                <div class="card">
                    <img src="https://i1.sndcdn.com/artworks-000452368242-4zrqgc-t500x500.jpg" alt="Capa do Álbum">
                    <div class="card-content">
                        <h3>Gotta Go Home</h3>
                        <p>BoneyM</p>
                        <span>Album</span>
                        <span>1978</span>
                        <audio id="audio3" src="1.mp3" type="audio/mpeg"></audio>
                        <button onclick="toggleAudio('audio3')">Play/Pause</button>
                    </div>
                </div>

                <div class="card">
                    <img src="../img/3.jpg" alt="Capa do Álbum">
                    <div class="card-content">
                        <h3>Rivers of Babylon</h3>
                        <p>BoneyM</p>
                        <span>Album</span>
                        <span>1978</span>
                        <audio id="audio3" src="1.mp3" type="audio/mpeg"></audio>
                        <button onclick="toggleAudio('audio3')">Play/Pause</button>
                    </div>
                </div>

                <div class="card">
                    <img src="https://i1.sndcdn.com/artworks-FV0nLBEngwtabt9o-Au37zQ-t500x500.jpg" alt="Capa do Álbum">
                    <div class="card-content">
                        <h3>Rasputin</h3>
                        <p>BoneyM</p>
                        <span>Album</span>
                        <span>1978</span>
                        <audio id="audio3" src="1.mp3" type="audio/mpeg"></audio>
                        <button onclick="toggleAudio('audio3')">Play/Pause</button>
                    </div>
                </div>

                <div class="card">
                    <img src="https://i1.sndcdn.com/artworks-FV0nLBEngwtabt9o-Au37zQ-t500x500.jpg" alt="Capa do Álbum">
                    <div class="card-content">
                        <h3>Rasputin</h3>
                        <p>BoneyM</p>
                        <span>Album</span>
                        <span>1978</span>
                        <audio id="audio3" src="1.mp3" type="audio/mpeg"></audio>
                        <button onclick="toggleAudio('audio3')">Play/Pause</button>
                    </div>
                </div>

                <div class="card">
                    <img src="https://i1.sndcdn.com/artworks-FV0nLBEngwtabt9o-Au37zQ-t500x500.jpg" alt="Capa do Álbum">
                    <div class="card-content">
                        <h3>Rasputin</h3>
                        <p>BoneyM</p>
                        <span>Album</span>
                        <span>1978</span>
                        <audio id="audio3" src="1.mp3" type="audio/mpeg"></audio>
                        <button onclick="toggleAudio('audio3')">Play/Pause</button>
                    </div>
                </div>

                <div class="card">
                    <img src="https://i1.sndcdn.com/artworks-FV0nLBEngwtabt9o-Au37zQ-t500x500.jpg" alt="Capa do Álbum">
                    <div class="card-content">
                        <h3>Rasputin</h3>
                        <p>BoneyM</p>
                        <span>Album</span>
                        <span>1978</span>
                        <audio id="audio3" src="1.mp3" type="audio/mpeg"></audio>
                        <button onclick="toggleAudio('audio3')">Play/Pause</button>
                    </div>
                </div>

                <div class="card">
                    <img src="https://i1.sndcdn.com/artworks-FV0nLBEngwtabt9o-Au37zQ-t500x500.jpg" alt="Capa do Álbum">
                    <div class="card-content">
                        <h3>Rasputin</h3>
                        <p>BoneyM</p>
                        <span>Album</span>
                        <span>1978</span>
                        <audio id="audio3" src="1.mp3" type="audio/mpeg"></audio>
                        <button onclick="toggleAudio('audio3')">Play/Pause</button>
                    </div>
                </div>

                <div class="card">
                    <img src="https://i1.sndcdn.com/artworks-FV0nLBEngwtabt9o-Au37zQ-t500x500.jpg" alt="Capa do Álbum">
                    <div class="card-content">
                        <h3>Rasputin</h3>
                        <p>BoneyM</p>
                        <span>Album</span>
                        <span>1978</span>
                        <audio id="audio3" src="1.mp3" type="audio/mpeg"></audio>
                        <button onclick="toggleAudio('audio3')">Play/Pause</button>
                    </div>
                </div>

                <div class="card">
                    <img src="https://i1.sndcdn.com/artworks-FV0nLBEngwtabt9o-Au37zQ-t500x500.jpg" alt="Capa do Álbum">
                    <div class="card-content">
                        <h3>Rasputin</h3>
                        <p>BoneyM</p>
                        <span>Album</span>
                        <span>1978</span>
                        <audio id="audio3" src="1.mp3" type="audio/mpeg"></audio>
                        <button onclick="toggleAudio('audio3')">Play/Pause</button>
                    </div>
                </div>

                <div class="card">
                    <img src="https://i1.sndcdn.com/artworks-FV0nLBEngwtabt9o-Au37zQ-t500x500.jpg" alt="Capa do Álbum">
                    <div class="card-content">
                        <h3>Rasputin</h3>
                        <p>BoneyM</p>
                        <span>Album</span>
                        <span>1978</span>
                        <audio id="audio3" src="1.mp3" type="audio/mpeg"></audio>
                        <button onclick="toggleAudio('audio3')">Play/Pause</button>
                    </div>
                </div>

                <div class="card">
                    <img src="https://i1.sndcdn.com/artworks-FV0nLBEngwtabt9o-Au37zQ-t500x500.jpg" alt="Capa do Álbum">
                    <div class="card-content">
                        <h3>Rasputin</h3>
                        <p>BoneyM</p>
                        <span>Album</span>
                        <span>1978</span>
                        <audio id="audio3" src="1.mp3" type="audio/mpeg"></audio>
                        <button onclick="toggleAudio('audio3')">Play/Pause</button>
                    </div>
                </div>

                <!-- Adicione mais cards aqui -->

            </div>
        </div>
    </div>

    <script>
    var currentAudio = null;

    function toggleAudio(id) {
        var audioElement = document.getElementById(id);

        if (currentAudio && currentAudio !== audioElement) {
            currentAudio.pause();
        }

        if (audioElement.paused) {
            audioElement.play();
            currentAudio = audioElement;
        } else {
            audioElement.pause();
            currentAudio = null;
        }
    }

    function goBack() {
        window.history.back();
    }
    </script>
</body>

</html>