<?php
    session_start();
    if (!isset($_SESSION["idUsuario"])) {
        header("location:../index.php?msg=Usuário e/ou senha inválidos");
        exit;
    }

    if (!isset($_GET["idUsuario"])) {
        header("location:../index.php?msg=Usuário não selecionado!");
        exit;
    }
    // Pesquisar no banco o usuário a ser alterado

    $nomeUsuario = $_SESSION["nomeUsuario"];
    $idUsuario = $_SESSION["idUsuario"];
    $perfil_idPerfil = $_SESSION["perfil_idPerfil"];

    require_once "../Model/UsuarioDTO.php";
    require_once "../Model/UsuarioDAO.php";

    $usuarioDAO = new UsuarioDAO();
    $idUsuario = $_GET["idUsuario"];

    $usuario = $usuarioDAO->buscarUsuarioPorId($idUsuario);

    if ($usuario == null) {
        header("location:../index.php?msg=Usuário não encontrado!");
        exit;
    }
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@300;400;500&display=swap" rel="stylesheet">
    <link href="../css/boot.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
    <link href="../css/login.css" rel="stylesheet">
    <link href="../css/formulario.css" rel="stylesheet">
    <link href="../css/fonticon.css" rel="stylesheet">
    <script type="text/javascript" src="../js/modal.js"></script>
    <link href="../css/modal.css" rel="stylesheet">
    <title>Alteração de Usuário</title>
    <style>
        /* Estilos personalizados aqui */

        body {
            font-family: 'Ubuntu', sans-serif;
        }

        .main_header {
            background-color: #f2f2f2;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .main_header_content {
            display: flex;
            align-items: center;
        }

        .logo img {
            height: 60px;
        }

        .listagem_info {
            margin-left: 20px;
        }

        .listagem_info .icon-blog {
            font-size: 18px;
            font-weight: 500;
        }

        .box {
            width: 400px;
            margin: 20px auto;
            background-color: #f2f2f2;
            padding: 20px;
            border-radius: 5px;
        }

        .box fieldset {
            border: none;
            padding: 0;
            margin: 0;
        }

        .box legend {
            font-weight: 500;
            font-size: 20px;
            margin-bottom: 10px;
        }

        .inputBox {
            position: relative;
            margin-bottom: 20px;
        }

        .inputBox input[type="text"],
        .inputBox input[type="tel"],
        .inputBox input[type="date"],
        .inputBox input[type="password"],
        .inputBox select {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: none;
            border-bottom: 1px solid #ccc;
            background-color: transparent;
        }

        .inputBox label {
            position: absolute;
            top: 0;
            left: 0;
            font-size: 16px;
            padding: 10px;
            pointer-events: none;
            transition: 0.5s;
        }

        .inputBox input[type="text"]:focus ~ label,
        .inputBox input[type="tel"]:focus ~ label,
        .inputBox input[type="date"]:focus ~ label,
        .inputBox input[type="password"]:focus ~ label,
        .inputBox select:focus ~ label,
        .inputBox input[type="text"]:valid ~ label,
        .inputBox input[type="tel"]:valid ~ label,
        .inputBox input[type="date"]:valid ~ label,
        .inputBox input[type="password"]:valid ~ label,
        .inputBox select:valid ~ label {
            top: -20px;
            left: 0;
            color: #ff0000;
            font-size: 14px;
        }

        .btn_alinhamento {
            text-align: center;
            margin-top: 20px;
        }

        .submit {
            padding: 10px 20px;
            background-color: #ff0000;
            border: none;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
        }

        .submit:focus,
        .submit:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <header class="main_header">
        <div class="main_header_content">
            <a href="../index.php" class="logo">
                <img src="../img/logo.png" alt="Bem vindo ao projeto prático Html5 e Css3 Essentials"
                    title="Bem vindo ao projeto prático Html5 e Css3 Essentials">
            </a>
            <div class="listagem_info">
                <samp class="icon-blog">Cadastro de Dados </samp>
            </div>
        </div>
    </header>

    <main>
        <div class="box">
            <form action="../Control/alterarUsuarioControl.php" method="POST">
                <fieldset>
                    <legend><b>Alteração de Usuário</b></legend>
                    <br>
                    <div class="inputBox">
                        <input type="text" name="nomeUsuario" id="nomeUsuario" class="inputUser"
                            value="<?php echo $usuario['nomeUsuario']; ?>" required>
                        <label for="nomeUsuario" class="labelInput">Nome completo</label>
                    </div>
                    <br>
                    <div class="inputBox">
                        <input type="text" name="email" id="email" class="inputUser"
                            value="<?php echo $usuario['email']; ?>" required>
                        <label for="email" class="labelInput">Email</label>
                    </div>
                    <br>
                    <div class="inputBox">
                        <input type="tel" name="telefone" id="telefone" class="inputUser"
                            value="<?php echo $usuario['telefone']; ?>" required>
                        <label for="telefone" class="labelInput">Telefone</label>
                    </div>
                    <br>
                    <div class="inputBox">
                        <input type="date" name="dtNascimento" id="dtNascimento" class="inputUser" required>
                        <label for="dtNascimento" class="labelInput"></label>
                    </div>
                    <br>
                    <?php
                    //testa se é o administrador 
                    if ($perfil_idPerfil == "1") {
                        //caso seja o usuário administrador, habilita o Perfil e a Situação do Usuário
                        echo '<div class="inputBox">
                            <select id="perfil_idPerfil" class="inputUser" name="perfil_idPerfil">
                               <option value="1" selected>Administrador</option>
                               <option value="2">Artista</option>
                               <option value="3">Usuário</option>
                               <option value="3">Anunciante</option>
                            </select>
                            <label for="perfil_idPerfil" class="labelInput">Perfil do Usuário:</label>
                            </div><br><br>
                            <div class="inputBox">
                            <select id="situacaoUsuario" class="inputUser" name="situacaoUsuario">
                               <option value="Ativo" selected>Ativo</option>
                               <option value="Inativo">Inativo</option>
                               <option value="Bloqueado">Bloqueado</option>
                            </select>
                            <label for="situacaoUsuario" class="labelInput">Situação do Usuário:</label>
                            </div><br><br>';
                    } else {
                        //caso NÃO seja o administrador, esconde o Perfil e a Situação do Usuário 
                        echo '<input type="hidden" name="perfil_idPerfil" value="3">
                                <input type="hidden" name="situacaoUsuario" value="Ativo">';
                    }
                    ?>
                    <div class="inputBox">
                        <input type="password" name="senha" id="senha" class="inputUser" required>
                        <label for="senha" class="labelInput">Senha:</label>
                    </div>
                    <br><br>
                </fieldset>
                <div class="btn_alinhamento">
                    <input type="submit" name="submit" id="submit" value="Salvar" class="submit">
                    <input type="reset" name="reset" id="reset" value="Limpar" class="submit">
                </div>
            </form>
        </div>
    </main>
</body>

</html>
