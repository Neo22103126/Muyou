<?php
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['idUsuario'])) {
    // Redireciona para a página de login ou exibe uma mensagem de erro
    header("Location: login.php");
    exit;
}

// Verifica se o formulário de alteração de senha foi enviado
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["alterar_senha"])) {
    // Lógica para alterar a senha aqui
    // ...

    // Exibe uma mensagem de sucesso ou erro
    $mensagem = "Senha alterada com sucesso!";
}

// Verifica se o formulário de configurações foi enviado
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["configuracoes"])) {
    // Lógica para salvar as configurações aqui
    // ...

    // Exibe uma mensagem de sucesso ou erro
    $mensagem = "Configurações salvas com sucesso!";
}

// Lógica para obter os dados do usuário, como nome, email, etc.
// ...

$nomeUsuario = $_SESSION["nomeUsuario"];
$emailUsuario = $_SESSION["email"];

?>

<!DOCTYPE html>
<html>
<head>
    <title>Perfil do Usuário</title>
</head>
<body>
    <h1>Perfil do Usuário</h1>

    <h2>Dados do Usuário</h2>
    <p>Nome: <?php echo $nomeUsuario; ?></p>
    <p>Email: <?php echo $emailUsuario; ?></p>

    <h2>Alterar Senha</h2>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
        <label for="senha_atual">Senha Atual:</label>
        <input type="password" name="senha_atual" required><br>

        <label for="nova_senha">Nova Senha:</label>
        <input type="password" name="nova_senha" required><br>

        <label for="confirmar_senha">Confirmar Senha:</label>
        <input type="password" name="confirmar_senha" required><br>

        <input type="submit" name="alterar_senha" value="Alterar Senha">
    </form>

    <h2>Configurações</h2>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
        <!-- Campos de configuração aqui -->
        <!-- ... -->

        <input type="submit" name="configuracoes" value="Salvar Configurações">
    </form>

    <h2>Sair</h2>
    <form action="logout.php" method="POST">
        <input type="submit" name="sair" value="Sair">
    </form>

    <?php if (isset($mensagem)) {
        echo "<p>$mensagem</p>";
    } ?>
</body>
</html>
