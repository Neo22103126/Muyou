<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Direitos Autorais</title>
    <style>
    body {
        background-color: #1e1e1e;
        color: #fff;
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }

    .header {
        background-color: #333;
        padding: 20px;
        text-align: center;
    }

    .header h1 {
        font-size: 36px;
        margin-top: 0;
        color: #fff;
    }

    .container {
        max-width: 800px;
        margin: 0 auto;
        padding: 40px;
        text-align: center;
        border: 1px solid #666;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        background-color: #2c2c2c;
    }

    p {
        line-height: 1.5;
        margin-bottom: 20px;
    }

    .btn-back {
        display: inline-block;
        padding: 10px 20px;
        background-color: red;
        color: #fff;
        text-decoration: none;
        border-radius: 5px;
        transition: background-color 0.3s ease;
        border: none;
        font-weight: bold;
    }

    .btn-back:hover {
        background-color: #7b0000;
    }

    .social-icons {
        margin-top: 40px;
    }

    .social-icons a {
        display: inline-block;
        margin-right: 10px;
        color: #fff;
        font-size: 24px;
        transition: color 0.3s ease;
    }

    .social-icons a:hover {
        color: #aaa;
    }

    .background-image {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: -1;
        opacity: 0.3;
    }
    </style>
</head>

<body>
    <div class="header">
        <h1>Direitos Autorais</h1>
    </div>
    <div class="container">
        <p>Todo o conteúdo deste site está protegido por direitos autorais e pertence aos seus respectivos
            proprietários.</p>
        <p>Você não está autorizado a copiar, modificar, distribuir ou vender qualquer informação ou material deste site
            sem permissão por escrito dos proprietários dos direitos autorais.</p>
        <p>Se você acredita que algum conteúdo deste site viola seus direitos autorais, entre em contato conosco para
            que possamos resolver o problema.</p>
        <a href="../index.php" class="btn-back">Voltar</a>
        <div class="social-icons">
            <a href="#" target="_blank"><i class="fab fa-facebook"></i></a>
            <a href="#" target="_blank"><i class="fab fa-twitter"></i></a>
            <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
            <a href="#" target="_blank"><i class="fab fa-youtube"></i></a>
        </div>
    </div>
    <img class="background-image" src="https://postgrain.com/wp-content/uploads/2017/04/stockvault.jpg">