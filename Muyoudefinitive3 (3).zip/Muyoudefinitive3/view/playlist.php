<!DOCTYPE html>
<html>
<head>
    <title>Criação de Playlist</title>
</head>
<body>
    <h1>Criação de Playlist</h1>
    <form method="POST" action="criarPlaylist.php">
        <label for="nome">Nome da Playlist:</label>
        <input type="text" name="nome" id="nome" required><br><br>

        <label for="descricao">Descrição:</label>
        <textarea name="descricao" id="descricao"></textarea><br><br>

        <label for="musicas">Músicas (uma por linha):</label>
        <textarea name="musicas" id="musicas"></textarea><br><br>

        <input type="submit" value="Criar Playlist">
    </form>
    <h1>
    <a href="../index.php"><input type="submit" value="Voltar"></a>
    </h1>
    

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #222222;
        }

        h1 {
            color: rgb(255, 255, 255);
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }

        input[type="text"],
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            resize: vertical;
        }

        input[type="submit"] {
            background-color: #ff0000;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #7f1d1a;
        }
    </style>
</body>
</html>
