<?php
session_start();

require_once "../Model/Conexao.php";

if (isset($_SESSION["idUsuario"])) {
    $usuarioLogin = $_SESSION["nomeUsuario"];
    $idUsuarioLogin = $_SESSION["idUsuario"];
    $perfil_IdPerfil =  $_SESSION["perfil_idPerfil"];
} else {
    $usuarioLogin = "";
}

session_destroy();

?>

<style>
    .btn-back {
        display: inline-block;
        padding: 3px 10px;
        background-color: #111727;
        color: #fff;
        text-decoration: none;
        border-radius: 5px;
        transition: background-color 0.3s ease;
        border: none;
        font-weight: bold;
        margin-top: 20px;
    }

    .btn-back:hover {
        background-color: #111727;
    }
</style>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../css/login.css">

    <title>Muyou Login</title>
</head>

<body>
    <header>
        <div class="left_bx1">
            <div class="content">
                <form action="../Control/loginControl.php" method="POST">
                    <h3>Login</h3>
                    <div class="card">
                        <label for="email">Email</label>
                        <input type="text" name="email" placeholder="Insira seu Email..." required>
                    </div>
                    <div class="card">
                        <label for="password">Senha</label>
                        <input type="password" name="senha" placeholder="Insira sua Senha..." required>
                    </div>
                    <input type="submit" value="login" class="submit">
                    <div class="check">
                        <input type="checkbox" name="" id=""><span>Lembre de mim.</span>
                    </div>
                    <p>Ainda não tem uma conta? <a href="singup.php">Cadastro</a></p>
                </form>
                <a href="../index.php" class="btn-back">Voltar</a>
            </div>
        </div>
        <div class="right_bx1">
            <img src="../img/login_png.jpg" alt="">
            <!-- <h3>Incorrect Password</h3> -->
        </div>
    </header>
</body>

</html>
