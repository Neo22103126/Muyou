<?php
    require_once 'Conexao.php';
    require_once "UsuarioDTO.php";

    class UsuarioDAO {
        public function login($email, $senha){
            $pdo = Conexao::getInstance();
            $sql = "SELECT `idUsuario`, `nomeUsuario`, `email`, `senha`, `perfil_idPerfil`,P.nomePerfil 
                    FROM `usuario` U 
                    INNER JOIN perfil P ON U.perfil_idPerfil = P.idPerfil
                    WHERE `email` = :email AND `senha` = :senha";  

            $stmt = $pdo->prepare($sql); 
            $stmt->bindParam(":email", $email); 
            $stmt->bindParam(":senha", $senha);
            $stmt->execute();
            $retorno = $stmt->fetch(PDO::FETCH_ASSOC);         
            return $retorno;    
        }

        public function cadastrarUsuario(UsuarioDTO $usuarioDTO){
            try{
                $con = Conexao::getInstance();
                $sql = "INSERT INTO `usuario`(`nomeUsuario`, `email`, `senha`, `telefone`, `dtNascimento`, `situacaoUsuario`, `perfil_idPerfil`)
                        VALUES (:nomeUsuario, :email, :senha, :telefone, :dtNascimento, :situacaoUsuario, :perfil_idPerfil)";
                
                $stmt = $con->prepare($sql);
                
                $nomeUsuario = $usuarioDTO->getNomeUsuario();
                $email = $usuarioDTO->getEmail();
                $senha = $usuarioDTO->getSenha();
                $telefone = $usuarioDTO->getTelefone();
                $dtNascimento = $usuarioDTO->getDtNascimento();
                $situacaoUsuario = $usuarioDTO->getSituacaoUsuario();
                $perfil_idPerfil = $usuarioDTO->getPerfil_idPerfil();
                
                $stmt->bindParam(":nomeUsuario", $nomeUsuario);
                $stmt->bindParam(":email", $email);
                $stmt->bindParam(":senha", $senha);
                $stmt->bindParam(":telefone", $telefone);
                $stmt->bindParam(":dtNascimento", $dtNascimento);
                $stmt->bindValue(":situacaoUsuario", 'Ativo');
                $stmt->bindValue(":perfil_idPerfil", 3);
                
                $retorno = $stmt->execute();
                return $retorno;

            } catch(PDOException $e){
                echo $e->getMessage();
                die();
            }
        }

        public function buscarUsuarioPorId($idUsuario){
            try{
                $con = Conexao::getInstance();
                $sql = "SELECT * FROM `usuario` WHERE idUsuario = :idUsuario";
                
                $stmt = $con->prepare($sql);
                
                $stmt->bindParam(":idUsuario", $idUsuario);
                $stmt->execute();    
                $retorno = $stmt->fetch(PDO::FETCH_ASSOC);
                return $retorno;

            } catch(PDOException $e){
                echo $e->getMessage();
                die();
            }
        }

        public function alterarUsuario(UsuarioDTO $usuarioDTO){
            try{
                $con = Conexao::getInstance();
                $sql = "UPDATE `usuario` SET nomeUsuario = :nomeUsuario, email = :email, senha = :senha,
                        telefone = :telefone, dtNascimento = :dtNascimento, `situacaoUsuario` = :situacaoUsuario, perfil_idPerfil = :perfil_idPerfil WHERE idUsuario = :idUsuario";
                
                $stmt = $con->prepare($sql);
                
                $stmt->bindParam(":nomeUsuario", $usuarioDTO->getNomeUsuario());
                $stmt->bindParam(":email", $usuarioDTO->getEmail());
                $stmt->bindParam(":senha", $usuarioDTO->getSenha());
                $stmt->bindParam(":telefone", $usuarioDTO->getTelefone());
                $stmt->bindParam(":dtNascimento", $usuarioDTO->getDtNascimento());
                $stmt->bindParam(":situacaoUsuario", $usuarioDTO->getSituacaoUsuario());
                $stmt->bindParam(":perfil_idPerfil", $usuarioDTO->getPerfil_idPerfil());
                $stmt->bindParam(":idUsuario", $usuarioDTO->getIdUsuario());
                
                $retorno = $stmt->execute();
                return $retorno;

            } catch(PDOException $e){
                echo $e->getMessage();
                die();
            }
        }

        public function listarUsuarios(){
            try{
                $con = Conexao::getInstance();
                $sql = "SELECT * FROM `usuario` ORDER BY nomeUsuario";
                
                $stmt = $con->prepare($sql);
                
                $stmt->execute();    
                $retorno = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                return $retorno;

            } catch(PDOException $e){
                echo $e->getMessage();
                die();
            }
        }

        public function apagarUsuario($idUsuario){
            try{
                $con = Conexao::getInstance();
                $sql = "DELETE FROM `usuario` WHERE idUsuario = :idUsuario";
                
                $stmt = $con->prepare($sql);
                
                $stmt->bindParam(":idUsuario", $idUsuario);
                return $stmt->execute();    

            } catch(PDOException $e){
                echo $e->getMessage();
                die();
            }
        }
    }


?>