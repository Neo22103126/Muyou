<?php
class UsuarioDTO {

    private $idUsuario;
    private $nomeUsuario;
    private $email;
    private $senha;
    private $telefone;
    private $dtNascimento;
    private $situacaoUsuario;
    private $perfil_idPerfil;

    // Métodos set

    public function setIdUsuario($idUsuario){
        $this->idUsuario = $idUsuario;
    }

    public function setNomeUsuario($nomeUsuario){
        $this->nomeUsuario = $nomeUsuario;
    }

    public function setEmail($email){
        $this->email = $email;
    }

    public function setSenha($senha){
        $this->senha = $senha;
    }
   
    public function setTelefone($telefone){
        $this->telefone = $telefone;
    }
  
    public function setDtNascimento($dtNascimento){
        $this->dtNascimento = $dtNascimento;
    }   

    public function setSituacaoUsuario($situacaoUsuario){
        $this->situacaoUsuario = $situacaoUsuario;
    }

    public function setPerfil_idPerfil($perfil_idPerfil){
        $this->perfil_idPerfil = $perfil_idPerfil;
    }

    // Métodos GET

    public function getIdUsuario(){
        return $this->idUsuario;
    }

    public function getNomeUsuario(){
        return $this->nomeUsuario;
    }

    public function getEmail(){
        return $this->email;
    }

    public function getSenha(){
        return $this->senha;
    }

    public function getTelefone(){
        return $this->telefone;
    }

    public function getDtNascimento(){
        return $this->dtNascimento;
    }

    public function getSituacaoUsuario(){
        return $this->situacaoUsuario;
    }

    public function getPerfil_idPerfil(){
        return $this->perfil_idPerfil;
    } 
}


?>