<?php
    session_start();
    if(!isset($_SESSION["idUsuario"])){
      header ( "location:view/login.php?msg=Usuário e/ou senha inválidos" );	
	  exit; 

      
    }

    
 ?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/BoneyM.css">
    <title>Muyou</title>
</head>

<body>
    <header>
        <div class="menu_side">
            <h1><span></span><i></i>Muyou</h1>
            <div class="playlist">
                <h4 class="active"><span></span><i class="bi bi-music-note-beamed"></i> Músicas</h4>
                <a href="view/playlist.php">
                    <a href="../Muyoudefinitive3/view/Album.php">
                        <h4 class="active3"><span></span><i class="bi bi-music-note-beamed"></i>Álbum completo</h4>
                    </a>
                </a>
            </div>
            <div class="menu_song">
                <li class="songItem">
                    <span>01</span>
                    <img src="https://i1.sndcdn.com/artworks-FV0nLBEngwtabt9o-Au37zQ-t500x500.jpg" alt="">
                    <h5>Rasputin <br>
                        <div class="subtitle">Boney M</div>
                    </h5>
                    <i class="bi playlistPlay bi-play-circle-fill" id="1"></i>
                </li>
                <li class="songItem">
                    <span>02</span>
                    <img src="https://i1.sndcdn.com/artworks-000452368242-4zrqgc-t500x500.jpg" alt="">
                    <h5>On My Way <br>
                        <div class="subtitle">Alan Walker</div>
                    </h5>
                    <i class="bi playlistPlay bi-play-circle-fill" id="2"></i>
                </li>
                <li class="songItem">
                    <span>03</span>
                    <img src="../img/3.jpg" alt="">
                    <h5>On My Way <br>
                        <div class="subtitle">Alan Walker</div>
                    </h5>
                    <i class="bi playlistPlay bi-play-circle-fill" id="3"></i>
                </li>
                <li class="songItem">
                    <span>04</span>
                    <img src="../img/4.jpg" alt="">
                    <h5>On My Way <br>
                        <div class="subtitle">Alan Walker</div>
                    </h5>
                    <i class="bi playlistPlay bi-play-circle-fill" id="4"></i>
                </li>
                <li class="songItem">
                    <span>05</span>
                    <img src="https://i.discogs.com/sGJ_55-pdf-UkJ2lfQ6kT0dzkxLbbYUe4U-Fy3ak21c/rs:fit/g:sm/q:90/h:600/w:600/czM6Ly9kaXNjb2dz/LWRhdGFiYXNlLWlt/YWdlcy9SLTQzMzM3/MDItMTQ0ODIzODEw/Mi0xMTI4LmpwZWc.jpeg"
                        alt="">
                    <h5>On My Way <br>
                        <div class="subtitle">Alan Walker</div>
                    </h5>
                    <i class="bi playlistPlay bi-play-circle-fill" id="5"></i>
                </li>
                <li class="songItem">
                    <span>06</span>
                    <img src="https://i.discogs.com/sGJ_55-pdf-UkJ2lfQ6kT0dzkxLbbYUe4U-Fy3ak21c/rs:fit/g:sm/q:90/h:600/w:600/czM6Ly9kaXNjb2dz/LWRhdGFiYXNlLWlt/YWdlcy9SLTQzMzM3/MDItMTQ0ODIzODEw/Mi0xMTI4LmpwZWc.jpeg"
                        alt="">
                    <h5>On My Way <br>
                        <div class="subtitle">Alan Walker</div>
                    </h5>
                    <i class="bi playlistPlay bi-play-circle-fill" id="6"></i>
                </li>
                <li class="songItem">
                    <span>07</span>
                    <img src="https://i.discogs.com/sGJ_55-pdf-UkJ2lfQ6kT0dzkxLbbYUe4U-Fy3ak21c/rs:fit/g:sm/q:90/h:600/w:600/czM6Ly9kaXNjb2dz/LWRhdGFiYXNlLWlt/YWdlcy9SLTQzMzM3/MDItMTQ0ODIzODEw/Mi0xMTI4LmpwZWc.jpeg"
                        alt="">
                    <h5>On My Way <br>
                        <div class="subtitle">Alan Walker</div>
                    </h5>
                    <i class="bi playlistPlay bi-play-circle-fill" id="7"></i>
                </li>
                <li class="songItem">
                    <span>08</span>
                    <img src="https://i.discogs.com/sGJ_55-pdf-UkJ2lfQ6kT0dzkxLbbYUe4U-Fy3ak21c/rs:fit/g:sm/q:90/h:600/w:600/czM6Ly9kaXNjb2dz/LWRhdGFiYXNlLWlt/YWdlcy9SLTQzMzM3/MDItMTQ0ODIzODEw/Mi0xMTI4LmpwZWc.jpeg"
                        alt="">
                    <h5>On My Way <br>
                        <div class="subtitle">Alan Walker</div>
                    </h5>
                    <i class="bi playlistPlay bi-play-circle-fill" id="8"></i>
                </li>
            </div>
        </div>
        <div class="song_side">
            <nav>
                <ul>
                    <a href="index.php">
                        <li>Voltar <span></span></li>
                    </a>
                </ul>
                <div class="search">
                    <i class="bi bi-search"></i>
                    <input type="text" placeholder="Search Music...">
                    <div class="search_results">

                    </div>
                </div>
                <div class="user">
                    <img src="img/KDS CODER.png" alt="">
                    <div class="dropdown">
                        <button class="dropbtn">Perfil</button>
                        <div class="dropdown-content">
                        </div>
                    </div>
                </div>
            </nav>
            <div class="content">
                <h1>Boney M</h1>
                <p>Boney M é um grupo de disco músico europeu <br> que teve um grande sucesso durante os anos 70.</p>
                <div class="buttons">
                    <button>PLAY</button>
                </div>
            </div>

            <div class="popular_song">
                <div class="h4">
                    <h4>Popular Song</h4>
                    <div class="btn_s">
                        <i class="bi bi-arrow-left-short" id="pop_song_left"></i>
                        <i class="bi bi-arrow-right-short" id="pop_song_right"></i>
                    </div>
                </div>
                <div class="pop_song">
                    <li class="songItem">
                        <div class="img_play">
                            <img src="../img/2.jpg" alt="">
                            <i class="bi playlistPlay bi-play-circle-fill" id="9"></i>
                        </div>
                        <h5>On My Way <br>
                            <div class="subtitle">Alan Walker</div>
                        </h5>
                    </li>
                    <li class="songItem">
                        <div class="img_play">
                            <img src="../img/2.jpg" alt="">
                            <i class="bi playlistPlay bi-play-circle-fill" id="10"></i>
                        </div>
                        <h5>On My Way <br>
                            <div class="subtitle">Alan Walker</div>
                        </h5>
                    </li>
                    <li class="songItem">
                        <div class="img_play">
                            <img src="../img/2.jpg" alt="">
                            <i class="bi playlistPlay bi-play-circle-fill" id="11"></i>
                        </div>
                        <h5>On My Way <br>
                            <div class="subtitle">Alan Walker</div>
                        </h5>
                    </li>
                    <li class="songItem">
                        <div class="img_play">
                            <img src="../img/2.jpg" alt="">
                            <i class="bi playlistPlay bi-play-circle-fill" id="12"></i>
                        </div>
                        <h5>On My Way <br>
                            <div class="subtitle">Alan Walker</div>
                        </h5>
                    </li>
                    <li class="songItem">
                        <div class="img_play">
                            <img src="../img/2.jpg" alt="">
                            <i class="bi playlistPlay bi-play-circle-fill" id="13"></i>
                        </div>
                        <h5>On My Way <br>
                            <div class="subtitle">Alan Walker</div>
                        </h5>
                    </li>
                    <li class="songItem">
                        <div class="img_play">
                            <img src="../img/2.jpg" alt="">
                            <i class="bi playlistPlay bi-play-circle-fill" id="14"></i>
                        </div>
                        <h5>On My Way <br>
                            <div class="subtitle">Alan Walker</div>
                        </h5>
                    </li>
                    <li class="songItem">
                        <div class="img_play">
                            <img src="../img/2.jpg" alt="">
                            <i class="bi playlistPlay bi-play-circle-fill" id="15"></i>
                        </div>
                        <h5>On My Way <br>
                            <div class="subtitle">Alan Walker</div>
                        </h5>
                    </li>
                    <li class="songItem">
                        <div class="img_play">
                            <img src="../img/2.jpg" alt="">
                            <i class="bi playlistPlay bi-play-circle-fill" id="16"></i>
                        </div>
                        <h5>On My Way <br>
                            <div class="subtitle">Alan Walker</div>
                        </h5>
                    </li>
                    <li class="songItem">
                        <div class="img_play">
                            <img src="../img/2.jpg" alt="">
                            <i class="bi playlistPlay bi-play-circle-fill" id="17"></i>
                        </div>
                        <h5>On My Way <br>
                            <div class="subtitle">Alan Walker</div>
                        </h5>
                    </li>
                    <li class="songItem">
                        <div class="img_play">
                            <img src="../img/2.jpg" alt="">
                            <i class="bi playlistPlay bi-play-circle-fill" id="18"></i>
                        </div>
                        <h5>On My Way <br>
                            <div class="subtitle">Alan Walker</div>
                        </h5>
                    </li>
                    <li class="songItem">
                        <div class="img_play">
                            <img src="../img/2.jpg" alt="">
                            <i class="bi playlistPlay bi-play-circle-fill" id="19"></i>
                        </div>
                        <h5>On My Way <br>
                            <div class="subtitle">Alan Walker</div>
                        </h5>
                    </li>
                    <li class="songItem">
                        <div class="img_play">
                            <img src="../img/2.jpg" alt="">
                            <i class="bi playlistPlay bi-play-circle-fill" id="20"></i>
                        </div>
                        <h5>On My Way <br>
                            <div class="subtitle">Alan Walker</div>
                        </h5>
                    </li>
                </div>
            </div>
            <div class="popular_artists">
                <div class="h4">
                    <h4>Popular Artists</h4>
                    <div class="btn_s">
                        <i class="bi bi-arrow-left-short" id="pop_art_left"></i>
                        <i class="bi bi-arrow-right-short" id="pop_art_right"></i>
                    </div>
                </div>
                <div class="item Artists_bx">
                    <li>
                        <a href="ImagineDragons.php"><img
                                src="https://i.scdn.co/image/ab6761610000e5eb920dc1f617550de8388f368e" alt=""></a>
                    </li>

                    <li>
                        <a href="Ghostmane"><img
                                src="https://i1.sndcdn.com/artworks-79S1edzSMH6g6n1A-Q4oNXA-t500x500.jpg" alt=""></a>
                    </li>

                    <li>
                        <a href="Eminem"><img
                                src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBIWEhgVFhUYGBgYGBgYGBgYHBoYGBoaGhwaGRoYGBgcIS4lHB4rHxgaJjgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QHxISHjYrJCs1NDQ0NDY0NDQ0ND00NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0MTQ0NDQ0NP/AABEIAOEA4QMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAAAAQIDBAUGB//EADwQAAEDAgMGAggEBAcBAAAAAAEAAhEDIQQxQQUSUWFxkSKBBhMyobHB0fBCUuHxFCNyghUzYpKissI0/8QAGQEBAAMBAQAAAAAAAAAAAAAAAAECAwQF/8QAIxEBAQEAAQUAAgIDAAAAAAAAAAECEQMSITFBMlEEcRMUIv/aAAwDAQACEQMRAD8AzQlCaE5A4FKCmJwQOBTgmApQUD5RKaCh7w0STA5oHhOWZV2q38InmbDsqFfaLjqfKwQb1XEMZ7TgOWvYKjU2yB7LCeZMe4LFe5xumtEINGptioTmG9APnKhftOp+d3f6KmUwoLzdo1MxUd0kpw2xVH456gFZrShxQbLNvO/EwHmDH1V3DbTpvMTung765LlZQg7hhunvK5fZm1nMIa+7Pe3pxHJdIKgcAQQQciEDglCYCnBA8JU0JyASpJRKBUIQgEIQgzUqEIFlKmpUDpRKREoCpUDQXHIfcLAxWKc90mw0GgU21sVLtwZDPqqImECvOSGs1SgJ28BmgCU0pd7gPMpsEoG7yYVLu/cBIQgjhJCe8QmElA0hIlJSOCCMq7gNpvp2zacwfiOCpqNyDs8Jj6bxnB4HXodVcBXCYfEFtjcfDmF2Gz6+/Ta6ZORPMWQXQUBNBTgUD0JoTkAhCEAhCEFBCEIBCEIBNe6ATwBKcmVGyCOII7oOXL95xJ4qQWTKdMhxBEEEgoNzAy1PyCCT1hNhxz0/VPazXXiU5jE7dQMjndIWqWALqN1dmrgI855WCBJKY4JwrcGOPOCgFx/A7sgYTmtPC4bfoNLae+fWPBhpLvZploJAkN9s53us1zT+V3+0pjXDLXTiCgtYvC0w3eY4mSd0S2d1o8Ti3OS4GACfmoMZgnMc8SHBhALhbO4O6bwYzyUz9o17TUe4Zlr3Oe0j8pDjccslLRxdMua500nNDQHM3nghosN1xlps2DJvwgIMsi10wsWpXwxiXNcZPheDLIzzjxzaNRBHShUplpiRlNri/wACLjyKCDfIMi0iJ+S6L0ZqTTc3g6e4/RYRZK0vR55FUt0c0z1bl80HTBOCYE4IHBLKaEqByVMlOQKhIhBSQlQUDUJUqBEAJUoQYW1YFQxaQJ6xn2VSizRWseN6o7t2sogA0Se2c8AgdEILyfZy/MbDyGqAzV5/t0HU6n75qOrj2N5nlf35IJP4ZubnF3LIdgngtFmgN6AKiMVVf7DPM3+Nk8YDEOuXx0+gsotkWmbVsO46IFU5D3AfFQs2I4+089v1TzsH/W7t+qjuif8AHoOceJTHsOtxwzS/4NVFm1O8j6qGpQxLM27w5X/VJqVFzqBzAfwx0+mSY+mRpPSx7JG49sw5sffNWWQ4S0zy/dWVVaVbdNgCDZzXTB1uLHhexEKxXNNw3xIfIDmXIyMua7UTJvBE6ppY11ne1+bIqtUY9g4t/MPnwQNe4TYq1s2pFZjv9QH+63zVNrE+mS0g8CD2QdsnBUa20qTYl1yAYAJMESMlC/bNMN3g1xElugyAPHmg1ghV8LimvZvNyyg5g8CpwgchIllAspU1CCqhKghA1KlhCBE17oCdKr4k2hBjValyeJ+KbWrBnicfEcgNPvj5KPE1gwZeK8D3SqVKkXS95t8eqB7fWVTY7rfd+qvYfCUmXJBPE39yz61ZxECw5JjadTRruxVLWmculplmUjutPD0AYPNcpRwtUZNPZdDs6oQAHLHWuHVjHLWGFE8oSbjBmFZwbw4p+IpC9s1T/I1nS58Oex20abTICzK222n8C1sXsmm88OihZsGnNxPUq2d5Z66Wo53E4oP9po7fA5qpukGWkrrzsuiDYNPmCVVxGzm5gK86k+Mr0f259uJvDhfir9N4IvlyUjsI1wgj691D/hdRp8Bnkc1pNz6y10rPSviMPumW9voo98Ec1rM2XiC2XMDQATc68AAsW4dDhc/srTUvpTWbn3F2rH8txuN0A89xxEdgFsDaNAMdus8IgEQB7Uifd71jPvSZyc8f9T81tNxeGYAN2+60kBvEA5nPNSqn2TXpODgxu5EEjPzlaCw9h3qPcB4fqZA7LcQOBQkCVAIQhBXQlSIBCEIBUNpVgxhcfLror5XO+klQyxmkT3t8kGLUqFz5OputDcJbu8YVKnh3b8EEGRbXj8FtUKcFvVU1rhrjPPlDh6Qa4DK1zougwJp/hE84t3Kw9oMLSLZkdkHC1HhoDjrLQ4BonQcf1WVnd9dOf+Z4nLrHVGx7AMcDf4LNx5aW7zZBlM2dsZ8tJ3IDt6AImWxG8MhaYnUwArz9nxcvMT7MSB0Jv71ncyXxeWk1bnzOFTYGKPrN0rqsQwFtlz+Aww9ZIEaBdUyh4fJRqL51xOXN1abpPJZtQve8NBtxMhg5niunq0MyFEcLN1GYm6+OPqYzENO6LQ+PCGgEAxm6YkXm99OE2HxVdzN97WuuRABa62vCPoup/g3afGE4bNJMuy81e6nHHDLObLzbWXg8M13iLRPMX8wtHD4MAm0K7RwoGQV1lEQqptnLMxOG8B6LznHYaS4D2muJB88l6viGeEhcXsbCMfjixw8Il0crWWmNcSsurnu4ZuxNmGtTI3XndeTDBJu1tjY8FpO2XTa7xMuAB4pmAIEg8gvQcXjmUaZDG+LRrbeZOi53G4z19MlzNx7Li8y3UT71adad0lVv8W9t1PjIp02tENAA4AQPcnpEoW7kKlSBCBZQhCCBIlSIBCEIBQvwoe9oDA98gMtJk5AKYqXZ9csrscMw63Ugge8qKnM5vCvidi1aWJpetYWl7omQ4EAcWyreK2QA4kDIrT9INrCs7Cu3Yc2qQ4cLCTOoWr6kErK3mSuqZuLY46rs8nMZKxhNnHl5hdO7Z10NwgGippfNrNpYU6m3AJmMpCLLZFIDJVK9GVVpfPtQwlHxCy6ajQ8CoYDBOcbDzXQNwpDYlRwnmOdfTvClo0ZCkxlEtdEqXCtsqz2vfMRikU71ZIiFcFMJzmQFKvDPZh057YCskqvVco5R2qtd1iVyuxP/ALnumA0GT1K6TFvhhXP+jWBFapWlxA3QCeZNvKx7q+fVV17kdYKAe0uz3rg8Roqn8EIdaxY//qSl2BiGs/lvddpg9BaytbbrCnSfH4/A08nC57SqZndY21rszZ84ccEqELueQUISJUCoQhBDCQp6agahOhJCBFXrzmMxceSsFV67kHR+k+HaMI2qB4hUY9vmBrwkhaeCq7zGu5aKltkE4BgzJostz3Q75Kv6MYneoNBzaY5/d1z/AD+nfbzZb9jpg+QkLFCx4QHmVWrZTOYqmJbYhWt5VqzN5Qn+1R+26dKoGF4E2AJAk8laqbfi4uFym2Ng7zzv3be+UdeydRwlQNDQSG5QeHJRq+FsycrOJ9I2uxHq/ETEk5DoOK6fZ9QFoOi5hmzWvIIADmiJ1j9wuq2cxjabWjICx98qs9r6448LbbJj3pYJ0UbwpqsROKhfkpw1VsU+AYVU1jbXq/yyqPoNULnVWgmXFvYCS7nmVHtep4XCTlPY/qfcqfobX3a7gby0giSAcso48FtJxmsNfnHdYjZwdVYWttHicMo5lZPpPWbvNY32Wjucp+K3KdQuBkBoiA0WXI7RrB9RxFgPCOg/WVHRkt5T/I1Zji1VSoQup54QhCAQhCBiEIQCaU5CCN6z8S5aLmqtWYEHaYeg3EYZjw6D6sS0jIhu7bzC5b0fxQZvMNocfI3Ef8YXRejZ9Zg9wAEsc4TwHtAe9cM9/q8QfF+N4I83aHS/cFYzMlsde925leiUHyB0U7Z/dYuycQXAbxvaev7LaY/91TU4rXOuZysMCq43FNY0kn9+SdiMS0DnwHzzsuSxOKdVqkl0MbwzPHd4aqc5+1GtfIvVMWXvGcBu8b53JvysPfyV6q93q5gyRaxkc8tCsPEbRawQwQBwzKko+kFQt3QHEc2me5Cpqxv0+jq+02DrVGudvNItvSB4conlfT/V5qJu3KjSJzuSJtLTBJ+9OKj/AIqo7Jj8+BiVWxLA4t34aQbRmozZ9Tvo6zPDr9mbZa8gZTNjn3BWvmJXmeDrupvngZB42meRXd7LxofTnh8FOs/Yyzbfa2+yycfUgOJ4dgrVTE5nQCevRZGOxI3XEm0QZsLyq8L88RzOOeXPJixa6D0LZ+BWfsbF7mIacpcRpyi50srm0X7rjeSQAOEGHW58+JXPUSfXNjR09uI8lvJzHLrXbeXrW2NqsZTt7Th4R98FybHys+pVc4y4knmrFByvjHbGPV6nffHpcCVI1KrsghCECoSIQNKROSFAiEIQCq4lqtKOsLIINk7Xfh3ki7XCHDpkVjbUrB2Ic8SJcHjllPnIPuVqqLrN2lT9l40IHzCrZ9Xmrxw6fYuNyvBFm8LCCZ/tXVUMSCGjkY4yvNcHii1oiM9fL5DNdThtok05ysfLK5jmqXPl0Z14a+1qjRTPI3vE6xPCPksHY7DWbuh0XMuGnITmfcq21caXMhpu90QOENvzn5q/sSs1jLQN20DkPqq6nhOLzrlu4XYtFguSTqXXP0CnfWwzCPE1cttDab95zQTbjxuY6kAWXOYnHVHOAkkTI6Knba6v9jt9vUKWIwzhZzfmlfSoOzh3UArzPA4p5cI45Dz0HRdBgMRUDtbjegi0cjrl71XWbE5610v+kGzqZb4IbyAEXtJASejOOHq9yLs3geQEA+UweyV+JlrhM/hFuW9B+Hkubw9fcq7w8IJM8IJAPznTwqczmWM+pZNSx0+KxR3y2ZmRw0m/38Fn1sQQzeMxvA8hutn4hNxNQGoSNDHU3y8tVnY/FZmYjTMHSVbMV1vhW2riYcTAiZIkGBA8Nusz9FlYCPWjXPjrkosZVlxF5m/kIA9ytbKpeIu4fNbZnDk3rlrKxQCrhXaDVdistTkjQlQIUJSkQKhCEDUJUiBEJUIEUVXJTKKqLIMqvmoXMBEHJWMQ26iCDGcHMkRJn6RHYLYwNcFha3MCRe5ABtY2zj+0JuIwnrN0N9rLW82g+9Y7d+m64ILTDgcuHxVbF828Nas8gCZBGkXEAEDyPuKdSxrm7ojQARoRMnLPXy7Va+IDtyQbNcOMlsC97CN2x5p+GblMXI63OSiz9tJrz4bGDdTO857bum2ZDQACTzda5/eSps6mHuIBMAcIEzJaJ0vF9AqAAbUADhpJ5SJP/FaVTG7zYbYNcAYueY6S4kdFnZx6byy+1DZeGax5cHXaAZEWktDTB0BJ7hdHUrxSa8gAvPiYBO7vb0EdImNYPFc3gHsBdJiZGsFm9e/OPuVdZV9Y5wLvAA1o4ayOoaT05wo1Oatm8RZq1txoab7zWuDhmN42PAi4v1WZXG7ULyLiXG4uRJv78+KXE4gGoNIBaB0kS46ZfHiqGOxcy6RvezGc2Bj3+4qcxTWlrFYsta7d0JA4D2ptrFh/aFnY/ES5oiBAnUnTeM8ZKhZiiQRmMzJzsBfzuhuGe9+6BJN7Rl8lb8Wdt16VsPRL6gaM3Fo6ZBdCKG4SwmS1zgTxMm63NgbDbSDXOu8SSedx5LMx7f5z/wCt3xU513VXq57cxCzNX6AVOi1aFMLRgkQhCASJUICEIQgEiVCBEiUpEAmuFk5CDKxLbqABaWIoyqL27sk5BAlLEBlSmTfxsty3hJW/6S7BDyXN9q+eR+i47FP8QfoCOoAMr1TECR71TTbpfY8lq4dzHhrmmxiDlnnzn4BVqNd7X6zNweVoI816NtHZ7X5gcZ1B0hcftDYzmbxbdv6+881E1+06xfcQOxYibTrwm0T3Kio4v2vFnOeo+ZuqdVpabgZmRxnPyiAmOaRcX995OfO3vU8RXnS7SxnjyzMAC+cdzYWVlm0nNbutFpzyyjsL58+SyGUt7LRPbReRAvrHUXSyJl3V2pjt64EGNL8RPYjpCicQX3NjnzMEz2+KkwuzKjwCBln3C3cBsC7XG2RI1+5g+Sz1rOW2elq+2ZgdkPcbNOm8CLDPX5Lstk7MDAOPFWsJhWtbAH3qr9NkLHW7p0ZxMzwA2F59tWuWY2r+UuaSM82NuOa9CJXnfpSyMYT+ZjHfFv8A5WvR9ub+R6a9FgsRcG45qwFlbBxE0yw5sNv6TcdjI7LVXQ5DghIEqAQhCAQhCAQlSFAFNTimoBCEyvVaxpc4wB9wOJQFRwAJcYAzJXN47F77oFmjLnzKbj8e6oeDRk35nmqzBZAmMMiPivUNkYoVcNTfNyxs/wBQADh3BXl+Ib4V1PoNi4pupn8LpHR1/jKrqeF+neNOoqtWfWozotV7OyidTWFrrkYGJ2Ux8y0X791QfsFmgjnquqc1RvbyUWrScuVo+j4GZMHOLTyWnhdiUxHhk2uRwsMui16dNW6bAqW2tZJPik3BgaKemwQrLmpGMsqJ5FJtk8lOY1NephbETnXXBelLt7FmNGNaY5Fx/wDS7ms8C5XnOOqb+Ie/mQPKy6OlHF19fFZmJdTqNe3oRxHArrMNiWvYHtNj3B4HmuMxOfTNSbMx7qTpFwfabofoea3cztUoUOGxDHsD2GQe4PA81MECoQhAIQhA4ppTMTiqbPbcBy18hmsnE7a0Y2ObvkAg13uAEkgDiVn4ja9NuUuPKw7lYWIxTnmXOJ+HbRVHVhwQatfbFQ2BDemfcqlUeXGXEk8SZKgw5kk6BSIBqe0JrU8BA2oJC0PRiru1jzAWa9WdkOiqOijXpbP5R6Vhq28FM5nDssvBVLAhaDKkwubTtyhqyM7KErQc0nmO6oVaXC3wVeV+CMMffwVllVVBIzSyZtfkq1fMX96U+nyE9FBT7DylXKIjkoDmU+KhrkQVM96p4qpugn91aRnqsrauIgQOpXBU3SC/8xJXRbbrRTdxd4R1dn7p7Lm3+FsLqxPDj6t5qpVzTAE9yQhXZL2Axz6TpbcOzacjGvIrosHtWm+07rvyu+RyK5JuV9E5jxqg7tC5PC7RqMgB2838rrjyOYW3hNsU32Pgdwdl5Oy7oNFCZvBCDlcX/mP/AKioHIQgheqzkIQXMN/lnqnDTyQhA4fJSsy7oQgrv+al2Z/mj71CEKNeqtj8o7vZnsd1oOzQhctdk9rQ9jyULPaPl/5QhVntpfSo/XqnHNCFW+2k9LjdOgVofJCFCENPM9fks3amR80IWkZbcltzKn/Wf+pWJifZHRCF1Y9OPqe1UpdAhCszObkVCc/vgEIQWqeSR/y+qEIIEIQg/9k="
                                alt=""></a>
                    </li>

                    <li>
                        <a href="Poze do rodo"><img
                                src="https://akamai.sscdn.co/uploadfile/letras/fotos/1/c/b/6/1cb6b038ad909da30403a996fa0089c7.jpg"
                                alt=""></a>
                    </li>

                    <li>
                        <a href="ImagineDragons.php"><img
                                src="https://i.scdn.co/image/ab6761610000e5eb920dc1f617550de8388f368e" alt=""></a>
                    </li>

                    <li>
                        <a href="ImagineDragons.php"><img
                                src="https://i.scdn.co/image/ab6761610000e5eb920dc1f617550de8388f368e" alt=""></a>
                    </li>

                    <li>
                        <a href="ImagineDragons.php"><img
                                src="https://i.scdn.co/image/ab6761610000e5eb920dc1f617550de8388f368e" alt=""></a>
                    </li>

                    <li>
                        <a href="ImagineDragons.php"><img
                                src="https://i.scdn.co/image/ab6761610000e5eb920dc1f617550de8388f368e" alt=""></a>
                    </li>

                    <li>
                        <a href="ImagineDragons.php"><img
                                src="https://i.scdn.co/image/ab6761610000e5eb920dc1f617550de8388f368e" alt=""></a>
                    </li>

                    <li>
                        <a href="ImagineDragons.php"><img
                                src="https://i.scdn.co/image/ab6761610000e5eb920dc1f617550de8388f368e" alt=""></a>
                    </li>

                    <li>
                        <a href="ImagineDragons.php"><img
                                src="https://i.scdn.co/image/ab6761610000e5eb920dc1f617550de8388f368e" alt=""></a>
                    </li>

                    <li>
                        <a href="ImagineDragons.php"><img
                                src="https://i.scdn.co/image/ab6761610000e5eb920dc1f617550de8388f368e" alt=""></a>
                    </li>

                    <li>
                        <a href="ImagineDragons.php"><img
                                src="https://i.scdn.co/image/ab6761610000e5eb920dc1f617550de8388f368e" alt=""></a>
                    </li>

                    <li>
                        <a href="ImagineDragons.php"><img
                                src="https://i.scdn.co/image/ab6761610000e5eb920dc1f617550de8388f368e" alt=""></a>
                    </li>

                    <li>
                        <a href="ImagineDragons.php"><img
                                src="https://i.scdn.co/image/ab6761610000e5eb920dc1f617550de8388f368e" alt=""></a>
                    </li>

                    <li>
                        <a href="ImagineDragons.php"><img
                                src="https://i.scdn.co/image/ab6761610000e5eb920dc1f617550de8388f368e" alt=""></a>
                    </li>
                </div>
            </div>
        </div>



        <div class="master_play">
            <div class="wave" id="wave">
                <div class="wave1"></div>
                <div class="wave1"></div>
                <div class="wave1"></div>
            </div>
            <img src="img/20.jpg" alt="" id="poster_master_play">
            <h5 id="title">
                Rasputin
                <div class="subtitle">Boney M</div>
            </h5>
            <div class="icon">
                <i class="bi shuffle bi-music-note-beamed">next</i>
                <i class="bi bi-skip-start-fill" id="back"></i>
                <i class="bi bi-play-fill" id="masterPlay"></i>
                <i class="bi bi-skip-end-fill" id="next"></i>
                <a href="" id="download_music"><i class="bi bi-cloud-arrow-down-fill"></i></a>
            </div>
            <span id="currentStart">0:00</span>
            <div class="bar">
                <input type="range" id="seek" min="0" max="100">
                <div class="bar2" id="bar2"></div>
                <div class="dot"></div>
            </div>
            <span id="currentEnd">0:30</span>
            <div class="vol">
                <i class="bi bi-volume-up-fill" id="vol_icon"></i>
                <input type="range" min="0" max="100" id="vol">
                <div class="vol_bar"></div>
                <div class="dot" id="vol_dot"></div>
            </div>
        </div>

    </header>

    <script src="js/BoneyM.js"></script>

</body>

</html>