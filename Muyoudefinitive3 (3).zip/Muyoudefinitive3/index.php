<?php
session_start();

// Verifica se o usuário está logado
if (isset($_SESSION['idUsuario'])) {
    $nomeUsuario = $_SESSION['nomeUsuario'];
    $mensagem = "Olá, $nomeUsuario! Bem-vindo de volta.";
}

// Lógica para processar o formulário de login
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["login"])) {
    // Lógica de autenticação do usuário aqui
    // ...

    // Simulação de autenticação bem-sucedida
    $idUsuario = 1;
    $nomeUsuario = "João"; // Nome do usuário autenticado

    // Define os dados da sessão
    $_SESSION['idUsuario'] = $idUsuario;
    $_SESSION['nomeUsuario'] = $nomeUsuario;

    // Redireciona para a mesma página
    header("Location: index.php");
    exit;
}

// Lógica para processar o formulário de cadastro
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["cadastro"])) {
    // Lógica de cadastro do usuário aqui
    // ...

    // Exibe uma mensagem de sucesso ou erro
    $mensagem = "Cadastro realizado com sucesso!";
}

// Lógica para processar o logout
if (isset($_POST["logout"])) {
    // Limpa os dados da sessão
    session_unset();
    session_destroy();

    // Redireciona para a mesma página
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/index.css">
    <title>Document</title>
    <style>
    /* Estilos para o botão flutuante */
    .floating-button {
        position: fixed;
        right: 20px;
        bottom: 20px;
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background-color: #f44336;
        color: #fff;
        text-align: center;
        line-height: 50px;
        font-size: 24px;
        cursor: pointer;
    }
    </style>

</head>

<body>
    <div class="sidebar">
        <div class="logo">
            <a href="#">
                <img src="img/muyou.png" alt="Logo" />
            </a>
        </div>

        <div class="navigation">
            <ul>
                <li>
                    <a href="BoneyM.php">
                        <span class="fa fa-home"></span>
                        <span>Inicio</span>
                    </a>
                </li>

                <li>
                    <a href="https://chat.whatsapp.com/G9TbpcZjinn3VQrmFm2s2b">
                        <span class="fa fa-search"></span>
                        <span>Suporte</span>
                    </a>
                </li>
            </ul>
        </div>

        <div class="navigation">
            <ul>
                <li>
                    <a href="https://campanhadobem.com.br/campanhas/nossa-primeira-plataforma">
                        <span class="fa fas fa-heart"></span>
                        <span>Doação</span>
                    </a>
                </li>

                <li>
                    <a href="https://campanhadobem.com.br/campanhas/nossa-primeira-plataforma">
                        <span class="fa fas fa-heart"></span>
                        <span>Cadastro músicas</span>
                    </a>
                </li>

                <li>
                    <a href="index.php">
                        <span class="fa fas fa-heart"></span>
                        <span>Sair</span>
                    </a>
                </li>

            </ul>
        </div>

        <div class="policies">
            <ul>
                <li>
                    <a href="view/privacy.php">Privacy</a>
                </li>
            </ul>
        </div>
    </div>

    <div class="main-container">
        <div class="topbar">
            <div class="prev-next-buttons">
            </div>

            <div class="navbar">
                <?php if (isset($_SESSION['idUsuario'])) { ?>
                <ul>
                    <li class="divider">|</li>
                    <li>
                        <form>
                            <a href="view/listarUsuarios.php">lista de Usuario</a>
                        </form>
                    </li>
                </ul>
                <span>Bem-vindo, <?php echo $nomeUsuario; ?>!</span>
                <?php } else { ?>
                <ul>
                    <li class="divider">|</li>
                    <li>
                        <a href="view/singup.php">Cadastro</a>
                    </li>
                </ul>
                <a href="view/login.php"><button type="button">Login</button></a>
                <?php } ?>
            </div>
        </div>
        <div class="spotify-playlists">
            <h2>Muyou songs</h2>

            <div class="list">
                <div class="item">
                    <img src="https://i1.sndcdn.com/artworks-FV0nLBEngwtabt9o-Au37zQ-t500x500.jpg" />
                    <div class="play">
                        <button onclick="toggleMusica('audio/1.mp3')" id="playButton"><span id="toggleIcon"></span><span
                                id="toggleText">Play</span></button>
                    </div><br>
                    <h4>Rasputin</h4>
                    <p>Boney M</p>
                </div>



                <div class="item">
                    <img src="https://i1.sndcdn.com/artworks-000452368242-4zrqgc-t500x500.jpg" />
                    <div class="play">
                        <button onclick="toggleMusica('audio/2.mp3')" id="playButton"><span id="toggleIcon"></span><span
                                id="toggleText">Play</span></button>
                    </div><br>
                    <h4>Gotta Go Home</h4>
                    <p>Boney M</p>
                </div>



                <div class="item">
                    <img src="https://m.media-amazon.com/images/I/81YncRCVXYL._UF1000,1000_QL80_.jpg" />
                    <div class="play">
                        <button onclick="toggleMusica('audio/3.mp3')" id="playButton"><span id="toggleIcon"></span><span
                                id="toggleText">Play</span></button>
                    </div><br>
                    <h4>Rivers of Babylon</h4>
                    <p>Boney M</p>
                </div>



                <div class="item">
                    <img src="https://i1.sndcdn.com/artworks-000327068841-3vwvlo-t500x500.jpg" />
                    <div class="play">
                        <button onclick="toggleMusica('audio/4.mp3')" id="playButton"><span id="toggleIcon"></span><span
                                id="toggleText">Play</span></button>
                    </div><br>
                    <h4>Daddy Cool</h4>
                    <p>Boney M</p>
                </div>



                <div class="item">
                    <img
                        src="https://i.discogs.com/sGJ_55-pdf-UkJ2lfQ6kT0dzkxLbbYUe4U-Fy3ak21c/rs:fit/g:sm/q:90/h:600/w:600/czM6Ly9kaXNjb2dz/LWRhdGFiYXNlLWlt/YWdlcy9SLTQzMzM3/MDItMTQ0ODIzODEw/Mi0xMTI4LmpwZWc.jpeg" />
                    <div class="play">
                        <button onclick="toggleMusica('audio/5.mp3')" id="playButton"><span id="toggleIcon"></span><span
                                id="toggleText">Play</span></button>
                    </div><br>
                    <h4>Ma Baker</h4>
                    <p>Boney M</p>

                </div>
            </div>
        </div>


        <div class="spotify-playlists">
            <h2>Recentes</h2>
            <div class="list">
                <div class="item">
                    <img src="img/ImagineDragons/1.jpg" />
                    <div class="play">
                        <button onclick="toggleMusica('audio/18.mp3')" id="playButton"><span
                                id="toggleIcon"></span><span id="toggleText">Play</span></button>
                    </div><br>
                    <h4>Believe</h4>
                    <p>Imagine Dragons</p>
                </div>



                <div class="item">
                    <img src="img/ImagineDragons/2.jpg" />
                    <div class="play">
                        <button onclick="toggleMusica('audio/19.mp3')" id="playButton"><span
                                id="toggleIcon"></span><span id="toggleText">Play</span></button>
                    </div><br>
                    <h4>Radioctive</h4>
                    <p>Imagine Dragons</p>
                </div>



                <div class="item">
                    <img src="img/ImagineDragons/3.jpg" />
                    <div class="play">
                        <button onclick="toggleMusica('audio/20.mp3')" id="playButton"><span
                                id="toggleIcon"></span><span id="toggleText">Play</span></button>
                    </div><br>
                    <h4>Demons</h4>
                    <p>Imagine Dragons</p>
                </div>



                <div class="item">
                    <img
                        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT9ZtQRihpaydUZu-u1qKq5U4XqZ4elDW-CY30SLzYUJyP2JqDeDxA_mr3_RMR6BkluOhA&usqp=CAU" />
                    <div class="play">
                        <button id="playButton">Play</button><br></br>
                    </div><br>
                    <h4>My enemy</h4>
                    <p>Imagine Dragons</p>
                </div>



                <div class="item">
                    <img
                        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTEpRSZyLVIVWACAvfuu41-RIQFB5OcB0AIZKj3_owbA27GU4cmbpbWZFdaNuAHjgbMaEo&usqp=CAU" />
                    <div class="play">
                        <button id="playButton">Play</button><br></br>
                    </div><br>
                    <h4>Thunder</h4>
                    <p>Imagine Dragons</p>








                    <script src="https://kit.fontawesome.com/23cecef777.js" crossorigin="anonymous"></script>

                    <script src="js/index.js"></script>

                    <script>
                    var audio;
                    var playing = false;

                    function toggleMusica(arquivoAudio) {
                        if (playing) {
                            pausarMusica();
                        } else {
                            tocarMusica(arquivoAudio);
                        }
                    }

                    function tocarMusica(arquivoAudio) {
                        if (audio) {
                            audio.pause();
                        }

                        audio = new Audio(arquivoAudio);
                        audio.play();
                        playing = true;
                    }

                    function pausarMusica() {
                        if (audio) {
                            audio.pause();
                        }
                        playing = false;
                    }
                    </script>



                    <style>
                    #playButton {
                        padding: 5px 10px;
                        background-color: #ff0000;
                        color: white;
                        border: none;
                        cursor: pointer;
                        font-size: 16px;
                        border-radius: 4px;
                    }

                    #playButton:hover {
                        background-color: #7f1d1a;
                    }
                    </style>

</body>

</html>