<?php
  session_start();
  // Valida se existe SESSÃO aberta
  if(!isset($_SESSION["idUsuario"])){
     header ( "location:../index.php?msg=Usuário e/ou senha inválidos" );	
     exit; 
  }
  $perfilLogin = $_SESSION["perfil_idPerfil"];

  require_once "../Model/UsuarioDTO.php";
  require_once "../Model/UsuarioDAO.php";

   
  //Valida os campos do Formulário
  //if(!isset($_POST["senha"]) || empty($_POST["senha"])){
  //    header ( "location:../index.php?msg=Usuário e/ou senha inválidos" );	
	//   exit; 
  //}
  
   $usuarioDTO = new UsuarioDTO(); 

   //PASSA OS CAMPOS INPUT PARA OS CAMPOS DTO
   //$usuarioDTO->setIdUsuario("");
   $idUsuario = $_POST["idUsuario"];
   $nomeUsuario = strip_tags($_POST["nomeUsuario"]);
   $email = strip_tags($_POST["email"]);
   
   //Valida se houve mudança da senha cadastrada na base
   if(!Empty($_POST["senha"])){
     $senha = MD5($_POST["senha"]);
   } else {
    $senha = $_POST["senhaOculta"];
   }  

   $situacaoUsuario = $_POST["situacaoUsuario"];
   $perfil_idPerfil = $_POST["perfil_idPerfil"];
  
   $usuarioDTO->setNomeUsuario($nomeUsuario);
   $usuarioDTO->setEmail($email);
   $usuarioDTO->setSenha($senha);

   $usuarioDTO->setTelefone($telefone);
   
   $usuarioDTO->setSituacaoUsuario($situacaoUsuario);
   $usuarioDTO->setPerfil_idPerfil($perfil_idPerfil);
   $usuarioDTO->setIdUsuario($idUsuario);

   $usuarioDAO = new UsuarioDAO();
   $usuarioCadastro = $usuarioDAO->alterarUsuario($usuarioDTO);
   if($usuarioCadastro) {
    $msg="Usuário Alterado com sucesso";
   } else {
    $msg="Falha na Alteração de Usuário Cadastrado.";  
   }  
   if($perfilLogin == "1"){
    header ( "location:../View/listarUsuarios.php?msg=$msg" );
   } else { 
      header ( "location:../index.php?msg=$msg" );	
   } 
?>