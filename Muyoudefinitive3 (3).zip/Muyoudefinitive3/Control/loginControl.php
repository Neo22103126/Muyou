<?php
  session_start();
  if(!isset($_POST["senha"]) || empty($_POST["senha"])){
      header ( "location:../index.php?msg=Usuário e/ou senha inválidos" );	
	   exit; 
  }
   require_once "../Model/UsuarioDTO.php";
   require_once "../Model/UsuarioDAO.php";
   
   $email = strip_tags($_POST["email"]);
   $senha = MD5($_POST["senha"]);
   $usuarioDAO = new UsuarioDAO();
   $usuarioLogin = $usuarioDAO->login($email,$senha);

   if(!empty($usuarioLogin)){
     
     $_SESSION["idUsuario"] = $usuarioLogin["idUsuario"];
     $_SESSION["email"] = $usuarioLogin["email"];
     $_SESSION["nomeUsuario"] = $usuarioLogin["nomeUsuario"];
     $_SESSION["perfil_idPerfil"] = $usuarioLogin["perfil_idPerfil"];
     
     header ( "location:../BoneyM.php" );	
     exit; 

   } else {
     header ( "location:../index.php?msg=Usuário e/ou senha inválidos" );	
	   exit; 
   }

?>