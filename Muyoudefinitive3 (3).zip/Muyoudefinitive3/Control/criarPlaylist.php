<?php
// Estabelecer conexão com o banco de dados
$servername = "localhost";
$username = "seu_usuario";
$password = "sua_senha";
$dbname = "muyou";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Obter os dados do formulário
$nome = $_POST['nome'];
$descricao = $_POST['descricao'];
$musicas = $_POST['musicas'];

// Inserir a playlist no banco de dados
$sql = "INSERT INTO playlist (nome, descricao, musicas) VALUES ('$nome', '$descricao', '$musicas')";

if ($conn->query($sql) === TRUE) {
    echo "Playlist criada com sucesso!";
} else {
    echo "Erro ao criar a playlist: " . $conn->error;
}

// Fechar a conexão com o banco de dados
$conn->close();
?>
