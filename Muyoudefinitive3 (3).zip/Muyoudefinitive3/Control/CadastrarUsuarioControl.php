<?php
session_start();


require_once "../Model/UsuarioDTO.php";
require_once "../Model/UsuarioDAO.php";

// Verifica se os dados foram enviados via POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Cria uma instância do DTO e atribui os valores do formulário a ele
    $usuarioDTO = new UsuarioDTO();

    $nomeUsuario = isset($_POST["nomeUsuario"]) ? strip_tags($_POST["nomeUsuario"]) : "";
    $email = isset($_POST["email"]) ? strip_tags($_POST["email"]) : "";
    $senha = isset($_POST["senha"]) ? MD5($_POST["senha"]) : "";
    $telefone = isset($_POST["telefone"]) ? strip_tags($_POST["telefone"]) : "";
    $dtNascimento = isset($_POST["dtNascimento"]) ? $_POST["dtNascimento"] : "";
    $situacaoUsuario = isset($_POST["situacaoUsuario"]) ? $_POST["situacaoUsuario"] : "";
    $perfil_idPerfil = isset($_POST["perfil_idPerfil"]) ? $_POST["perfil_idPerfil"] : "";

    $usuarioDTO->setNomeUsuario($nomeUsuario);
    $usuarioDTO->setEmail($email);
    $usuarioDTO->setSenha($senha);
    $usuarioDTO->setTelefone($telefone);
    $usuarioDTO->setDtNascimento($dtNascimento);
    $usuarioDTO->setSituacaoUsuario($situacaoUsuario);
    $usuarioDTO->setPerfil_idPerfil($perfil_idPerfil);

    $usuarioDAO = new UsuarioDAO();
    $usuarioCadastro = $usuarioDAO->cadastrarUsuario($usuarioDTO);

    if ($usuarioCadastro) {
        $msg = "Usuário cadastrado com sucesso";
    } else {
        $msg = "Falha no cadastro de usuário";
    }

    // Redireciona para a página index.php com a mensagem de sucesso ou falha
    header("location:../index.php?msg=$msg");
} else {
    // Se os dados não forem enviados via POST, redireciona para a página de login
    header("location:../index.php");
}
?>

